function Navbar() {
  return (
    <div className="navbar">
      <div className="logo">Student Test App</div>
    </div>
  );
}
export default Navbar;
